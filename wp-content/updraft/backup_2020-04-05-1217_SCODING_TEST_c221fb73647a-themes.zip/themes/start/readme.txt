=== Start ===
Start WordPress Theme, Copyright (C) 2015, munirkamal
Start is distributed under the terms of the GNU GPL
Underscores Starter Theme - http://underscores.me/ Distributed under the terms of the GPLv2 Automattic, Inc.
Contributors: munirkamal
Tags: gray, blue, white, light, two-columns, right-sidebar
Requires at least: 4.1
Tested up to: 4.3.1
Stable tag: 4.3.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
StartWP is the most user-friendly WordPress theme. It can help you create amazing website easier and faster than ever. It fits creative business, small businesses (restaurants, wedding planners, sport/medical shops), startups, corporate businesses, online agencies and firms, portfolios, ecommerce (WooCommerce), and freelancers. It is a multipurpose theme, compatible with most page builders. The most organized customizer ever which feels like a page builder. Boost site performance, No bloat, No frameworks & No Jquery.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.
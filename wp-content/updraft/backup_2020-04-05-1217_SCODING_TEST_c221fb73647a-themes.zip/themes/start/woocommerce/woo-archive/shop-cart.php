<div class="swp-archive-cart">
<?php do_action( 'swp_woocommerce_template_loop_add_to_cart' ); ?>
</div>
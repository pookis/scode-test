<div class="swp-archive-rating">
<?php do_action( 'swp_woocommerce_template_loop_rating' ); ?>
</div>
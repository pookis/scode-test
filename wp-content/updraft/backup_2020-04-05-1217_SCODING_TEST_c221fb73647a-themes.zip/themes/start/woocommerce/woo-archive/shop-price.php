<div class="swp-archive-price">
<?php do_action( 'swp_woocommerce_template_loop_price' ); ?>
</div>
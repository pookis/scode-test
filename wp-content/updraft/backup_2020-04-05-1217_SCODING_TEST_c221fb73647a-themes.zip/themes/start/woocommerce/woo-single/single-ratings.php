<div class="swp-single-rating">
<?php do_action('swp_woocommerce_template_single_rating'); ?>
</div>
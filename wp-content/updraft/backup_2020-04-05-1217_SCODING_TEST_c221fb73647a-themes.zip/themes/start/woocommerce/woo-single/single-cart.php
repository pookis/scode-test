<div class="swp-single-cart">
<?php do_action('swp_woocommerce_template_single_add_to_cart'); ?>
</div>
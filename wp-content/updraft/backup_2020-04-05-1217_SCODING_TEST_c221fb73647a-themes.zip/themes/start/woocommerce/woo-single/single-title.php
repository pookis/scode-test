<div class="swp-single-title">
<?php do_action('swp_woocommerce_template_single_title'); ?>
</div>
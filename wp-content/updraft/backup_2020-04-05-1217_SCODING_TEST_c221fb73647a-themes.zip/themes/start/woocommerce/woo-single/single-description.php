<div class="swp-single-description">
<?php do_action('swp_woocommerce_template_single_excerpt'); ?>
</div>
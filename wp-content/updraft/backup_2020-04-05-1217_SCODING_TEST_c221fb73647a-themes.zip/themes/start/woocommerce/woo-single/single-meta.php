<div class="swp-single-meta">
<?php do_action('swp_woocommerce_template_single_meta'); ?>
</div>
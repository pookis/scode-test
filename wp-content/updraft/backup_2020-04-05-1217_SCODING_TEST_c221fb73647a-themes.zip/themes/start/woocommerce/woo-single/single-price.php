<div class="swp-single-price">
<?php do_action('swp_woocommerce_template_single_price'); ?>
</div>
<?php
/**
 *
 * @package scoding
 *
 */
?>




<?php wp_footer();?>

</body>

</html>